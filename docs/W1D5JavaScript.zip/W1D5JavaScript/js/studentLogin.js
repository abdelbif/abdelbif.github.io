"use strict";

window.onload = function(){
  const loginForm = document.getElementById("btnSubmit");
  
  loginForm.onsubmit = function(event){
    event.preventDefault();
    const emailInput = document.getElementById("EmailAddress");
    const passInput = document.getElementById("Password");
    const urlInput = document.getElementById("url");
    // const btn = document.getElementsById("btnSubmit");
    const email = emailInput.value;
    const pass = passInput.value;
    const url = urlInput.value;

    console.log('The Email is ${email}');
    console.log('The password is ${pass}');
    console.log('The url is ${url}');
  }

}  

